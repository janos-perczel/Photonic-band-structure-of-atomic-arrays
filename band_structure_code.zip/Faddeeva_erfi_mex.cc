#define FADDEEVA_FUNC Faddeeva::erfi
#define FADDEEVA_REAL 1
#include "Faddeeva_mex.cc"
